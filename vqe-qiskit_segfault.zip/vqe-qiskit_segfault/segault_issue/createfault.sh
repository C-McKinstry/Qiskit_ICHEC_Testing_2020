#!/bin/bash

module load conda
conda create --prefix testenvironment python=3.7 -y
source activate ./testenvironment
conda install numpy -y
pip install qiskit
python replicate_seg_fault.py  
